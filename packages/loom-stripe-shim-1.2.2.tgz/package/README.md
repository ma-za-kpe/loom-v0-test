# `@loom/stripe-shim` v1.2.2

`stripe-shim` is Loom's canonical vendor-adapter thread for Stripe. This
version is the first real adapter package in the `v1.2.2` line:

- `createStripeClient()` builds a configured `Stripe` SDK client
- `createPaymentIntent()` wraps `stripe.paymentIntents.create()`
- `verifyStripeWebhook()` wraps `Stripe.webhooks.constructEvent()`

The package is intentionally narrow. It is meant to prove the abstraction
layer Loom patches against: installable vendor wrappers with real upstream
churn, real SDK calls, and testable webhook verification.

## Local build

```bash
npm ci
npm test
npm pack
```

`build.sh` performs the same steps and then writes a CycloneDX SBOM beside the
package artifacts.
